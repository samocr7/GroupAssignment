public class Environment
{
    private double temp;
    public Environment(double temp){
        this.temp=temp;
    }
    
    public double getTemp() { return temp; }
}
